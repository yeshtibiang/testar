// ---------------------------------------------------------------------------
// Reglages globaux de l'experience.
// ---------------------------------------------------------------------------

export const CONFIG = {
  // Orientation du personnage une fois pose.
  //   'fixed' : garde l'orientation du moment ou on l'a pose (choix actuel).
  //             L'utilisateur peut tourner autour ; vu de profil un decoupage
  //             plat disparait (c'est le comportement demande).
  //   'yaw'   : billboard sur l'axe Y, fait toujours face a la camera.
  //   'soft'  : fixe, mais pivote doucement pour rester lisible quand la camera
  //             depasse SOFT_BILLBOARD_MAX_DEG. Bon compromis pour un decoupage.
  orientationMode: 'fixed',

  // Utilise seulement en mode 'soft'.
  softBillboardMaxDeg: 55,
  softBillboardSpeed: 2.5, // rad/s

  // Placement --------------------------------------------------------------
  // Un hitTest au-dela de cette distance est ignore : au-dela de ~12 m, les
  // points de feature SLAM sont trop bruites pour un placement credible.
  maxPlacementDistance: 12,

  // Le point vise doit etre au moins X metres SOUS la camera pour etre
  // considere comme du sol (evite de coller le joueur sur un mur ou une table).
  // 0.6 m rejette une table basse tout en laissant passer un sol vise
  // telephone tenu bas.
  minDropBelowCamera: 0.6,

  // Une fois le niveau du sol connu, un hit situe plus de X metres AU-DESSUS de
  // ce niveau est refuse : impossible de reposer le joueur sur une table apres
  // l'avoir pose par terre. Genereux pour rester compatible avec une marche.
  floorBandTolerance: 0.5,

  // Stabilisation du niveau du sol : on lisse les hauteurs des hits successifs.
  // Si un nouveau hit est a moins de floorSnapTolerance du niveau estime, on
  // l'aligne dessus -> le joueur ne "flotte" plus d'un tap a l'autre.
  floorSnapTolerance: 0.35,
  floorSmoothing: 0.15, // 0 = fige, 1 = suit chaque mesure

  // Reticule ---------------------------------------------------------------
  reticleHitTestHz: 15,
  // Position du hitTest du reticule en coordonnees ecran normalisees (0..1).
  // 0.5 / 0.62 = un peu sous le centre, la ou on vise naturellement le sol.
  reticleScreenX: 0.5,
  reticleScreenY: 0.62,

  // Photo ------------------------------------------------------------------
  screenshot: {
    maxDimension: 2048, // 8th Wall par defaut : 1280. 2048 = photo partageable.
    jpgCompression: 92,
  },
  shareTitle: 'Kayfo AR',
  shareText: 'Photo prise en realite augmentee avec Kayfo AR.',

  // Debug ------------------------------------------------------------------
  // Affiche "camera : X m" dans le HUD.
  //
  // NE PAS s'en servir pour CALCULER `slamScaleCorrection` ci-dessous, sous
  // aucune forme (ni `affiche / reel`, ni une formule a deux points). Essaye
  // et abandonne deux fois : sur le terrain, en levant reellement le
  // telephone de 0,19 m a 1,92 m, la valeur affichee a BAISSE (0,50 -> 0,20)
  // au lieu d'augmenter — l'estimation verticale du SLAM n'est pas assez
  // stable pour servir de signal de calcul, quel que soit le modele. Voir
  // src/lib/scale.js pour le detail.
  //
  // Ce debug reste utile pour UNE seule chose : verifier qu'un sol EST
  // detecte (une valeur qui ne bouge jamais quel que soit le mouvement indique
  // un suivi qui n'accroche pas). Pas pour juger ou calculer une taille.
  debugScale: true,

  // Calibration de l'echelle absolue -----------------------------------------
  //
  // L'estimation metrique du SLAM monoculaire de 8th Wall est une ESTIMATION,
  // pas une mesure garantie. `reality.trackingstatus === 'NORMAL'` signifie
  // seulement que le suivi 6 degres de liberte est stable — pas que l'echelle
  // ait fini de converger. Sur certains appareils/environnements (peu de
  // texture au sol, mouvement de calibration trop bref ou trop petit), l'erreur
  // peut etre importante.
  //
  // Deux garde-fous, complementaires :

  // 1. On exige un vrai deplacement de la camera (pas juste un statut) avant
  //    d'autoriser le placement. `minCalibrationTravel` est la distance totale
  //    (en unites de scene, sommee sur tous les mouvements) que le telephone
  //    doit avoir parcourue depuis la derniere perte de suivi. Une simple
  //    rotation sur place ne compte quasiment pas : il faut une vraie
  //    translation (avancer/reculer), qui est ce qui donne au SLAM la
  //    parallaxe necessaire pour estimer l'echelle. C'est ce garde-fou, pas la
  //    correction manuelle ci-dessous, qui fait la majeure partie du travail :
  //    en pratique une calibration complete ne laisse qu'un residu de
  //    quelques %.
  minCalibrationTravel: 0.6,

  // Plafond de distance comptee par frame (metres). La camera XR8 peut subir
  // des SAUTS ponctuels de position (reparentage lors d'un changement d'etat,
  // recalage interne...) qui n'ont rien a voir avec un vrai mouvement de la
  // main. Sans ce plafond, un seul de ces sauts suffirait a satisfaire
  // `minCalibrationTravel` d'un coup, ce qui viderait le garde-fou de son
  // sens. 0,08 m/frame reste largement au-dessus de ce qu'un mouvement de main
  // reel produit a 30-60 fps, donc ca ne penalise pas un vrai deplacement —
  // ca plafonne juste sa contribution au lieu de le compter integralement.
  maxTravelPerFrame: 0.08,

  // 2. Correction residuelle du biais d'echelle. Multiplicateur applique aux
  //    hauteurs de personnage, au diametre du reticule, ET a tous les seuils
  //    de distance ci-dessus (via src/lib/scale.js) — sans quoi un moteur qui
  //    sous-estime l'echelle rendrait `minDropBelowCamera: 0.6` equivalent a
  //    1,2 m reels et rejetterait des hits de sol parfaitement valides.
  //
  //    UNIQUEMENT par comparaison VISUELLE — voir src/lib/scale.js pour la
  //    raison precise pour laquelle toute formule basee sur le debug
  //    "camera : X m" a ete essayee puis abandonnee :
  //    a. Ouvrez l'app avec ?calibrate (ex. https://<domaine>/?calibrate).
  //    b. Faites une vraie calibration par deplacement (avant/arriere) jusqu'a
  //       ce que l'app autorise le placement.
  //    c. Posez le repere 1,80 m a cote d'un objet reel connu — porte
  //       (≈2,04-2,10 m), metre ruban, une personne de taille connue.
  //    d. Ajustez avec les boutons ± du panneau jusqu'a ce que la taille
  //       affichee corresponde, puis reportez le nombre ici.
  //
  //    Laisse a 1 par defaut : une valeur codee en dur mesuree ailleurs est
  //    pire que pas de correction du tout, car elle se cumule silencieusement
  //    avec l'erreur du moteur au lieu de la corriger. Ne figez une valeur ici
  //    que si vous la retrouvez de facon reproductible sur plusieurs lieux.
  slamScaleCorrection: 1,
}

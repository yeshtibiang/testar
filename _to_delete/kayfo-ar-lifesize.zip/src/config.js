// ---------------------------------------------------------------------------
// Reglages globaux de l'experience.
// ---------------------------------------------------------------------------

export const CONFIG = {
  // Orientation du personnage une fois pose.
  //   'fixed' : garde l'orientation du moment ou on l'a pose (choix actuel).
  //             L'utilisateur peut tourner autour ; vu de profil un decoupage
  //             plat disparait (c'est le comportement demande).
  //   'yaw'   : billboard sur l'axe Y, fait toujours face a la camera.
  //   'soft'  : fixe, mais pivote doucement pour rester lisible quand la camera
  //             depasse SOFT_BILLBOARD_MAX_DEG. Bon compromis pour un decoupage.
  orientationMode: 'fixed',

  // Utilise seulement en mode 'soft'.
  softBillboardMaxDeg: 55,
  softBillboardSpeed: 2.5, // rad/s

  // Placement --------------------------------------------------------------
  // Un hitTest au-dela de cette distance est ignore : au-dela de ~12 m, les
  // points de feature SLAM sont trop bruites pour un placement credible.
  maxPlacementDistance: 12,

  // Le point vise doit etre au moins X metres SOUS la camera pour etre
  // considere comme du sol (evite de coller le joueur sur un mur ou une table).
  // 0.6 m rejette une table basse tout en laissant passer un sol vise
  // telephone tenu bas.
  minDropBelowCamera: 0.6,

  // Une fois le niveau du sol connu, un hit situe plus de X metres AU-DESSUS de
  // ce niveau est refuse : impossible de reposer le joueur sur une table apres
  // l'avoir pose par terre. Genereux pour rester compatible avec une marche.
  floorBandTolerance: 0.5,

  // Stabilisation du niveau du sol : on lisse les hauteurs des hits successifs.
  // Si un nouveau hit est a moins de floorSnapTolerance du niveau estime, on
  // l'aligne dessus -> le joueur ne "flotte" plus d'un tap a l'autre.
  floorSnapTolerance: 0.35,
  floorSmoothing: 0.15, // 0 = fige, 1 = suit chaque mesure

  // Reticule ---------------------------------------------------------------
  reticleHitTestHz: 15,
  // Position du hitTest du reticule en coordonnees ecran normalisees (0..1).
  // 0.5 / 0.62 = un peu sous le centre, la ou on vise naturellement le sol.
  reticleScreenX: 0.5,
  reticleScreenY: 0.62,

  // Photo ------------------------------------------------------------------
  screenshot: {
    maxDimension: 2048, // 8th Wall par defaut : 1280. 2048 = photo partageable.
    jpgCompression: 92,
  },
  shareTitle: 'Kayfo AR',
  shareText: 'Photo prise en realite augmentee avec Kayfo AR.',

  // Debug ------------------------------------------------------------------
  // Affiche dans le HUD la hauteur camera mesuree + la distance du hit.
  // C'est LA verification a faire pour valider l'echelle absolue :
  // camera ~1.40-1.70 m quand on tient le telephone a hauteur de poitrine.
  debugScale: true,

  // Calibration de l'echelle absolue -----------------------------------------
  //
  // L'estimation metrique du SLAM monoculaire de 8th Wall est une ESTIMATION,
  // pas une mesure garantie. `reality.trackingstatus === 'NORMAL'` signifie
  // seulement que le suivi 6 degres de liberte est stable — pas que l'echelle
  // ait fini de converger. Sur certains appareils/environnements (peu de
  // texture au sol, mouvement de calibration trop bref ou trop petit), l'erreur
  // peut etre importante : x2, x3, voire plus.
  //
  // Deux garde-fous, complementaires :

  // 1. On exige un vrai deplacement de la camera (pas juste un statut) avant
  //    d'autoriser le placement. `minCalibrationTravel` est la distance totale
  //    (en unites de scene, sommee sur tous les mouvements) que le telephone
  //    doit avoir parcourue depuis la derniere perte de suivi. Une simple
  //    rotation sur place ne compte quasiment pas : il faut une vraie
  //    translation (avancer/reculer), qui est ce qui donne au SLAM la
  //    parallaxe necessaire pour estimer l'echelle.
  minCalibrationTravel: 0.6,

  // Plafond de distance comptee par frame (metres). La camera XR8 peut subir
  // des SAUTS ponctuels de position (reparentage lors d'un changement d'etat,
  // recalage interne...) qui n'ont rien a voir avec un vrai mouvement de la
  // main. Sans ce plafond, un seul de ces sauts suffirait a satisfaire
  // `minCalibrationTravel` d'un coup, ce qui viderait le garde-fou de son
  // sens. 0,08 m/frame reste largement au-dessus de ce qu'un mouvement de main
  // reel produit a 30-60 fps, donc ca ne penalise pas un vrai deplacement —
  // ca plafonne juste sa contribution au lieu de le compter integralement.
  maxTravelPerFrame: 0.08,

  // 2. Correction manuelle residuelle, pour rattraper un biais systematique de
  //    l'appareil/l'environnement que le point 1 ne suffit pas a corriger.
  //    C'est un multiplicateur applique a TOUTES les hauteurs de personnage.
  //
  //    Comment le mesurer :
  //    a. Ouvrez l'app avec ?calibrate (ex. https://<ip>:5173/?calibrate).
  //    b. Tenez le telephone a une hauteur que vous mesurez reellement (metre
  //       ruban, ou dos contre un mur marque). Notez la valeur affichee par
  //       le debug "camera : X m" a CETTE hauteur precise.
  //    c. slamScaleCorrection = (valeur affichee) / (hauteur reelle mesuree).
  //       Exemple : telephone tenu a 1,50 m reel, debug affiche 0,65 m
  //       -> slamScaleCorrection = 0,65 / 1,50 ≈ 0,43.
  //    d. Le panneau de calibration (?calibrate) permet d'ajuster cette valeur
  //       EN DIRECT en comparant le personnage repere (1,80 m) a un objet reel
  //       connu (porte ≈ 2,04 m, metre ruban, personne de taille connue) :
  //       ajustez jusqu'a ce que la taille affichee corresponde, puis reportez
  //       le nombre obtenu ici pour qu'il s'applique par defaut.
  slamScaleCorrection: 1,
}

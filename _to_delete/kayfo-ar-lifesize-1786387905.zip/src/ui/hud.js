import {CONFIG} from '../config.js'
import {PLAYERS, DEFAULT_PLAYER_ID, getPlayer} from '../players.js'
import {getCameraWorldY} from '../lib/hit-test.js'
import {setCorrection} from '../lib/scale.js'
import {
  configureScreenshots,
  takeScreenshot,
  base64ToFile,
  canShareFile,
  shareFile,
  makeFilename,
} from './photo.js'

// ---------------------------------------------------------------------------
// Interface HTML posee au-dessus du canvas AR.
// Aucune logique 3D ici : on ecoute les evenements `ar-*` emis par ar-director.
// ---------------------------------------------------------------------------

const MESSAGES = {
  booting: {label: 'Demarrage de la camera...', hint: 'Autorisez l’acces a la camera'},
  calibrating: {
    label: 'Calibration de l’echelle',
    // Message par defaut ; remplace en direct par la progression du
    // deplacement mesure (voir 'ar-calibration-progress' plus bas). Le
    // suivi 6DoF peut etre stable ('tracking' OK) sans que l'echelle ait
    // fini de converger — c'est pour ca qu'on insiste sur le DEPLACEMENT
    // et pas juste "attendez".
    hint: 'Deplacez le telephone d’avant en arriere, lentement et largement',
  },
  ready: {label: 'Echelle calibree', hint: 'Visez le sol puis tapez pour poser le joueur'},
  placed: {label: 'Joueur pose', hint: 'Tapez ailleurs pour le deplacer · reculez pour entrer dans le cadre'},
}

export function initHud(sceneEl) {
  const el = {
    hud: document.getElementById('hud'),
    statusText: document.getElementById('status-text'),
    badge: document.getElementById('status-badge'),
    hint: document.getElementById('hint'),
    strip: document.getElementById('player-strip'),
    shoot: document.getElementById('btn-shoot'),
    reset: document.getElementById('btn-reset'),
    recenter: document.getElementById('btn-recenter'),
    flash: document.getElementById('flash'),
    fallback: document.getElementById('share-fallback'),
    preview: document.getElementById('share-preview'),
    shareNow: document.getElementById('btn-share-now'),
    download: document.getElementById('btn-download'),
    shareClose: document.getElementById('btn-share-close'),
  }

  const figureEl = document.getElementById('figure')
  const reticleEl = document.getElementById('reticle')
  const director = () => sceneEl.components['ar-director']

  let state = 'booting'
  let currentPlayerId = DEFAULT_PLAYER_ID
  let busy = false
  let pendingFile = null
  let pendingUrl = null

  // -- selection du joueur -------------------------------------------------

  // `correction` demarre a la valeur configuree, mais le panneau ?calibrate
  // (plus bas) peut l'ajuster en direct : on la garde en variable locale pour
  // que changer de joueur ne fasse pas perdre le reglage en cours de session.
  let scaleCorrection = CONFIG.slamScaleCorrection

  // La correction s'applique au personnage ET au reticule : le reticule fait
  // 0,45 m et sert de repere visuel, il doit donc subir exactement la meme
  // correction, sinon il indiquerait une taille fausse au moment ou on s'en
  // sert pour juger celle du personnage.
  // Point unique de mise a jour : les composants visuels recoivent la
  // correction par attribut (donc testable hors AR), et src/lib/scale.js la
  // recoit pour convertir les SEUILS de distance du placement. Les deux
  // doivent rester synchronises — d'ou cette fonction unique.
  const applyCorrection = () => {
    setCorrection(scaleCorrection)
    figureEl.setAttribute('real-scale-figure', 'correction', scaleCorrection)
    if (reticleEl) reticleEl.setAttribute('ground-reticle', 'correction', scaleCorrection)
  }

  const applyPlayer = (id) => {
    const p = getPlayer(id)
    currentPlayerId = p.id
    figureEl.setAttribute('real-scale-figure', {
      src: p.src,
      height: p.heightMeters,
      calibration: p.calibration ?? 1,
      feetInset: p.feetInset ?? 0,
      correction: scaleCorrection,
    })
    ;[...el.strip.children].forEach((b) => b.classList.toggle('is-active', b.dataset.id === p.id))
    applyCorrection()
  }

  PLAYERS.forEach((p) => {
    const btn = document.createElement('button')
    btn.type = 'button'
    btn.className = 'chip'
    btn.dataset.id = p.id
    btn.innerHTML = `<span class="chip__name">${p.name}</span><span class="chip__h">${p.heightMeters.toFixed(
      2
    )} m</span>`
    btn.addEventListener('click', () => applyPlayer(p.id))
    el.strip.appendChild(btn)
  })
  applyPlayer(currentPlayerId)

  // -- etats ---------------------------------------------------------------

  const render = () => {
    const msg = MESSAGES[state] || MESSAGES.booting
    el.hud.dataset.state = state
    el.statusText.textContent = msg.label
    el.hint.textContent = msg.hint
    el.shoot.disabled = state !== 'placed' || busy
    el.reset.disabled = state !== 'placed'
  }

  sceneEl.addEventListener('ar-state', (e) => {
    state = e.detail.state
    render()
  })

  const REJECT_REASONS = {
    tracking: 'Suivi pas encore stable — bougez le telephone',
    calibration: 'Echelle pas encore fiable — continuez a deplacer le telephone',
    'no-surface': 'Aucune surface detectee ici — visez un sol texture',
  }
  sceneEl.addEventListener('ar-place-rejected', (e) => {
    flashHint(REJECT_REASONS[e.detail.reason] || REJECT_REASONS['no-surface'])
  })

  // Pendant la calibration, remplace le hint generique par la progression
  // reelle du deplacement mesure : plus concret que "patientez", et ca
  // rassure que l'app n'est pas figee.
  sceneEl.addEventListener('ar-calibration-progress', (e) => {
    if (state !== 'calibrating' || hintTimer) return // ne coupe pas une alerte en cours
    const {fraction, trackingNormal} = e.detail
    if (!trackingNormal) {
      el.hint.textContent = 'Recherche du suivi — balayez lentement la piece'
      return
    }
    const pct = Math.round(fraction * 100)
    el.hint.textContent =
      pct < 100
        ? `Continuez a deplacer le telephone d’avant en arriere — ${pct}%`
        : 'Calibration presque terminee...'
  })

  sceneEl.addEventListener('figure-error', () => {
    flashHint('Image du joueur introuvable — verifiez public/players/')
  })

  let hintTimer = null
  function flashHint(text) {
    clearTimeout(hintTimer)
    el.hint.textContent = text
    el.hint.classList.add('hint--alert')
    hintTimer = setTimeout(() => {
      // Remis a null : sinon plus aucune progression de calibration ne
      // pourrait jamais s'afficher apres la toute premiere alerte, le garde-fou
      // de 'ar-calibration-progress' la croirait indefiniment "en cours".
      hintTimer = null
      el.hint.classList.remove('hint--alert')
      render()
    }, 2600)
  }

  // -- debug echelle --------------------------------------------------------
  //
  // AVANT que `scaleReady` soit vrai (etats 'booting'/'calibrating'), 8th Wall
  // n'a pas encore converge sur une estimation metrique : ce que renvoie
  // getCameraWorldY() a ce moment n'a pas de raison de correspondre a quoi que
  // ce soit de reel — ca peut meme ressembler par coincidence a la hauteur
  // reelle du telephone. C'est ce qui a cause une vraie confusion sur le
  // terrain : une lecture "correcte" (~0,9 m) AVANT calibration, qui
  // s'effondre a ~0,20 m juste APRES — pas parce que la calibration "detruit"
  // quoi que ce soit, mais parce que c'est seulement a cet instant que le
  // moteur applique pour la premiere fois sa VRAIE estimation d'echelle
  // (convergee, mais possiblement tres biaisee). D'ou le marquage explicite
  // ci-dessous : une lecture prise pendant 'booting'/'calibrating' est
  // etiquetee comme non significative, pour ne plus jamais la confondre avec
  // la valeur finale.
  if (CONFIG.debugScale) {
    const dbg = document.createElement('div')
    dbg.className = 'debug'
    el.hud.appendChild(dbg)
    setInterval(() => {
      const y = getCameraWorldY(sceneEl)
      const val = Number.isFinite(y) ? `${y.toFixed(2)} m` : '—'
      const notYetConverged = state === 'booting' || state === 'calibrating'
      dbg.textContent = notYetConverged ? `camera : ${val} (pas encore calibre)` : `camera : ${val}`
    }, 400)
  }

  // -- boutons --------------------------------------------------------------

  el.reset.addEventListener('click', () => director() && director().clear())

  el.recenter.addEventListener('click', () => {
    // recenter() relance l'estimation de pose sans redemarrer la camera.
    if (window.XR8 && window.XR8.XrController) window.XR8.XrController.recenter()
    const d = director()
    if (d) {
      // La pose repart de zero : on force aussi une nouvelle calibration de
      // l'echelle plutot que de garder l'ancienne mesure de deplacement.
      d.resetTravel()
      d.updateScaleReadiness()
      d.clear()
    }
    flashHint('Suivi reinitialise — bougez le telephone pour recalibrer')
  })

  el.shoot.addEventListener('click', async () => {
    if (busy) return
    busy = true
    render()
    triggerFlash()

    // Le reticule est dans la scene 3D : il apparaitrait donc sur la photo.
    reticleEl.setAttribute('ground-reticle', 'active', false)
    reticleEl.object3D.visible = false
    await nextFrame()

    try {
      const base64 = await takeScreenshot(sceneEl)
      const file = base64ToFile(base64, makeFilename())

      const result = canShareFile(file) ? await shareFile(file) : 'unsupported'
      if (result === 'shared' || result === 'cancelled') {
        releasePending()
      } else {
        // 'blocked' (activation perdue) ou 'unsupported' (desktop, Firefox...)
        openFallback(file)
      }
    } catch (err) {
      console.error('[kayfo-ar]', err)
      flashHint('La capture a echoue — reessayez')
    } finally {
      reticleEl.setAttribute('ground-reticle', 'active', state === 'placed' || state === 'ready')
      busy = false
      render()
    }
  })

  const nextFrame = () =>
    new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)))

  function triggerFlash() {
    if (navigator.vibrate) navigator.vibrate(12)
    el.flash.classList.remove('flash--on')
    void el.flash.offsetWidth // force le reflow pour rejouer l'animation
    el.flash.classList.add('flash--on')
  }

  // -- panneau de repli -----------------------------------------------------

  function releasePending() {
    if (pendingUrl) URL.revokeObjectURL(pendingUrl)
    pendingUrl = null
    pendingFile = null
  }

  function openFallback(file) {
    releasePending()
    pendingFile = file
    pendingUrl = URL.createObjectURL(file)
    el.preview.src = pendingUrl
    el.download.href = pendingUrl
    el.download.download = file.name
    el.shareNow.hidden = !canShareFile(file)
    el.fallback.hidden = false
  }

  el.shareNow.addEventListener('click', async () => {
    if (!pendingFile) return
    const r = await shareFile(pendingFile)
    if (r === 'shared') closeFallback()
  })

  el.shareClose.addEventListener('click', closeFallback)

  function closeFallback() {
    el.fallback.hidden = true
    el.preview.removeAttribute('src')
    releasePending()
  }

  // -- panneau de calibration (?calibrate) -----------------------------------
  //
  // HISTORIQUE — pourquoi ce panneau ne calcule plus rien a partir du debug
  // "camera : X m" :
  //
  // Deux methodes numeriques ont ete tentees et abandonnees :
  //   1. correction = affiche / reel (une seule lecture)
  //   2. correction = (affiche_haut - affiche_bas) / (reel_haut - reel_bas)
  //      (deux lectures, pour annuler l'offset du plan de sol)
  //
  // La seconde s'est effondree sur le terrain : en levant reellement le
  // telephone de 0,19 m a 1,92 m (+1,73 m), la valeur AFFICHEE a BAISSE
  // (0,50 -> 0,20 m). Une hauteur qui augmente ne peut pas produire une
  // lecture qui diminue, quel que soit le modele (proportionnel, affine, avec
  // ou sans offset) : l'estimation de position VERTICALE du SLAM n'est tout
  // simplement pas assez stable ici pour servir de signal de calcul, pas
  // seulement biaisee par un offset previsible. Ce n'est pas une erreur de
  // methode, mais une limite reelle de la donnee de depart.
  //
  // La SEULE methode qui a produit un resultat correct sur le terrain dans ce
  // projet reste la comparaison VISUELLE (voir plus bas) : elle ne depend
  // d'aucune lecture numerique, seulement de ce que l'oeil voit. Le debug
  // "camera : X m" reste affiche, mais uniquement comme verification que le
  // sol EST detecte (une valeur qui ne bouge jamais indique un suivi qui
  // n'accroche pas) — plus jamais comme entree d'un calcul.
  //
  // Cache par defaut : c'est un outil de mise au point, pas une fonctionnalite
  // pour l'utilisateur final. On l'active avec ?calibrate dans l'URL.
  if (new URLSearchParams(location.search).has('calibrate')) {
    const panel = document.createElement('div')
    panel.className = 'calib'
    panel.innerHTML = `
      <div class="calib__row">
        <span class="calib__label">Correction d’echelle</span>
        <span class="calib__value" id="calib-value"></span>
      </div>
      <div class="calib__row">
        <span class="calib__label">Camera (info, sol detecte ?)</span>
        <span class="calib__value" id="calib-cam">—</span>
      </div>
      <div class="calib__buttons">
        <button type="button" data-step="-0.1">−10%</button>
        <button type="button" data-step="-0.02">−2%</button>
        <button type="button" data-step="0.02">+2%</button>
        <button type="button" data-step="0.1">+10%</button>
      </div>
      <p class="calib__hint">
        Posez le repere 1,80 m a cote d’un objet reel connu (porte ≈ 2,04 m,
        metre ruban, une personne) et ajustez avec les boutons jusqu’a ce que
        la taille corresponde — c’est la <strong>seule</strong> methode
        fiable. Reportez la valeur dans <code>CONFIG.slamScaleCorrection</code>
        (src/config.js) pour la garder.
      </p>
    `
    document.body.appendChild(panel)

    const valueEl = panel.querySelector('#calib-value')
    const camEl = panel.querySelector('#calib-cam')

    const renderValue = () => {
      valueEl.textContent = `× ${scaleCorrection.toFixed(3)}`
    }
    renderValue()

    // Purement informatif : verifie qu'un sol EST detecte, ne sert plus a
    // calculer quoi que ce soit (voir l'avertissement ci-dessus).
    setInterval(() => {
      const y = getCameraWorldY(sceneEl)
      camEl.textContent = Number.isFinite(y) ? `${y.toFixed(2)} m` : '—'
    }, 300)

    panel.querySelectorAll('button[data-step]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const step = Number(btn.dataset.step)
        // Multiplicatif plutot qu'additif : un pas de 10% a un sens constant
        // que la correction courante soit 0,4 ou 2,5.
        scaleCorrection = Math.max(0.05, scaleCorrection * (1 + step))
        renderValue()
        applyCorrection()
      })
    })
  }

  // -- init -----------------------------------------------------------------

  const onXrReady = () => configureScreenshots()
  if (window.XR8) onXrReady()
  else window.addEventListener('xrloaded', onXrReady, {once: true})

  render()
}

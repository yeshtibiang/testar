# Kayfo AR — joueur en taille réelle

Application web de réalité augmentée : on tape sur le sol pour poser un joueur
**à sa taille réelle**, on se place à côté de lui, et on prend une photo qu'on
partage via la feuille de partage native du téléphone.

Construit sur le **binaire 8th Wall** (`@8thwall/engine-binary`) en mode
**absolute scale**, avec **A-Frame** pour la scène et **Vite** pour le build.

---

## Démarrer

```bash
npm install
npm run dev      # sert en HTTPS sur toutes les interfaces (https://<ip-lan>:5173)
```

Puis ouvrez l'URL réseau sur votre téléphone. Le certificat est auto-signé :
acceptez l'avertissement une fois.

> **HTTPS obligatoire.** `getUserMedia` et `DeviceMotionEvent` sont bloqués en
> `http://` sur mobile. C'est pour ça que `@vitejs/plugin-basic-ssl` est câblé
> dans `vite.config.js` — ne le retirez pas pour tester sur téléphone.

Autres commandes :

```bash
npm run build    # bundle de production dans dist/
npm run preview  # sert dist/ en HTTPS — la bonne façon de tester un build
npm test         # vérifie les invariants d'échelle et le filtrage des hitTest
```

> **Ne testez jamais un build en ouvrant `dist/index.html` directement**, ni en
> le servant depuis un serveur dont la racine est le dossier du projet. La
> caméra exige un contexte sécurisé, et `dist/` attend d'être servi comme une
> racine de site. `npm run preview` fait exactement ça.

Pour itérer sur la mise en page depuis un ordinateur : `https://localhost:5173/?desktop`.
Le moteur démarre en émulation clavier/souris — **mais sans centrale inertielle
il n'y a ni SLAM ni échelle métrique.** Ne jamais valider une taille depuis ce mode.

---

## Ajouter un joueur

1. Déposez le PNG détouré (fond transparent) dans `public/players/`.
2. Ajoutez une entrée dans `src/players.js` :

```js
{
  id: 'mon-joueur',
  name: 'Mon joueur',
  src: '/players/mon-joueur.png',
  heightMeters: 1.88,   // ← la seule valeur qui compte
  calibration: 1,
  feetInset: 0,
}
```

Rien d'autre. Le recadrage est automatique — voir ci-dessous.

---

## Comment la taille réelle est garantie

Quatre mécanismes se combinent. C'est leur empilement qui donne un résultat
crédible, pas un seul d'entre eux.

### 1. La scène est en mètres

```html
<a-scene xrweb="scale: absolute">
```

Le paramètre `scale` du composant `xrweb` bascule le moteur de `responsive`
(unités arbitraires, défaut) à `absolute` : caméra, hit tests et cibles image
sont alors exprimés **en mètres réels**. Une entité de 1,88 unité mesure
1,88 m à l'écran, point.

Trois contraintes du moteur, vérifiées dans le binaire :

| Contrainte | Conséquence |
|---|---|
| `scale` doit être fixé **avant** `XR8.run()` | Impossible de basculer à chaud (`Error: Scale can only be changed before calling XR8.run()`) |
| Incompatible avec `disableWorldTracking: true` | Lève une exception |
| Incompatible avec VPS / Area Targets | Repasse silencieusement en `responsive` |

### 2. L'échelle n'est utilisable qu'après calibration

L'estimation métrique est **monoculaire** : le moteur a besoin de parallaxe pour
la résoudre. Tant qu'elle n'est pas convergée, l'événement `xrtrackingstatus`
rapporte `status: 'LIMITED', reason: 'INITIALIZING'`.

`@8thwall/coaching-overlay` affiche automatiquement « Avancez et reculez le
téléphone » pendant cette phase, et `src/components/ar-director.js` **refuse tout
placement** tant que `status` n'est pas passé à `'NORMAL'`. Sans ce verrou, un
joueur posé trop tôt apparaît à une taille aléatoire — c'est le piège n°1 de
l'absolute scale.

### 3. Le PNG est recadré sur ses pixels opaques

C'est le point que la plupart des implémentations ratent.

Un détourage laisse toujours des marges transparentes, et elles diffèrent d'une
image à l'autre. Dimensionner le plan sur la hauteur du **fichier** fait donc
varier la taille perçue de ±15 % selon le détourage.

`src/lib/texture.js` mesure la bounding box des pixels dont `alpha > 10`,
recadre dessus, et `real-scale-figure` dimensionne le plan sur **cette** hauteur.
`heightMeters` correspond alors exactement au sujet — semelles au sol, sommet du
crâne à `heightMeters`.

L'origine de l'entité `#figure-root` est **au sol**, pas au centre du plan : le
placement se réduit à recopier la position du hit test.

`npm test` verrouille cet invariant :

```
OK    hauteur du sujet = 1.80 m
OK    semelles a y = 0
OK    sommet a y = 1.80 m
OK    calibration 0.9 -> 1.62 m
```

### 4. Le point d'ancrage est filtré, pas pris tel quel

`XR8.XrController.hitTest(x, y, ['FEATURE_POINT'])` renvoie **plusieurs**
estimations de qualité inégale. `src/lib/hit-test.js` applique :

- **plausibilité** — un hit à plus de 12 m est rejeté ; un hit à moins de 60 cm
  sous la caméra n'est pas du sol ; et une fois le niveau du sol connu, tout hit
  situé plus de 50 cm au-dessus est refusé (c'est ce qui empêche de reposer le
  joueur sur une table après l'avoir posé par terre) ;
- **qualité** — `DETECTED_SURFACE` > `ESTIMATED_SURFACE` > `FEATURE_POINT`, puis
  le plus proche ;
- **stabilisation** — une moyenne glissante du niveau du sol aligne les
  placements successifs. Sans elle le joueur saute de quelques centimètres à
  chaque déplacement, ce qui casse immédiatement l'illusion.

Si aucun candidat ne passe, **rien n'est posé** et le HUD affiche « Aucune
surface détectée ici ». Poser au mauvais endroit coûte plus cher que ne rien
faire.

**`findGroundHit` élargit la recherche autour du point visé.** Les points de
feature du SLAM sont **épars** — ce n'est pas une carte de profondeur dense.
Un sol réel a presque toujours des zones de quelques pixels sans aucun point
matché, même quand la zone juste à côté en a plein (carrelage lisse, reflet,
zone surexposée). Sans marge, taper à quelques pixels d'un point valide
échouait systématiquement, alors que le sol était pourtant bien suivi juste
à côté — c'était la cause de « je vise le sol, je tape, ça refuse toujours ».
`findGroundHit` (dans `src/lib/hit-test.js`) essaie donc le point exact, puis
16 points voisins répartis sur deux anneaux (rayons 3 % et 6 % de l'écran),
et s'arrête au premier qui rend un hit plausible. Utilisé à la fois par le
réticule et par le tap de placement.

### Vérifier sur le terrain

`CONFIG.debugScale` affiche « camera : X m » en direct — mais il ne sert plus
qu'à **une seule chose : confirmer qu'un sol est détecté** (une valeur qui ne
bouge jamais, quel que soit le mouvement du téléphone, indique un suivi qui
n'accroche pas). Il ne doit **plus jamais** servir à calculer une correction —
voir l'avertissement détaillé juste après.

Le personnage `Repère 1,80 m` fourni est gradué tous les 50 cm : posez-le contre
une porte (≈ 2,04 m) pour valider d'un coup d'œil — c'est **la seule** méthode
fiable, voir ci-dessous.

> **« La calibration détruit la hauteur caméra »** — observé sur le terrain :
> ~0,9 m (plausible) avant calibration, qui s'effondre à ~0,20 m juste après le
> déplacement de calibration. Ce n'est pas une destruction : **avant** que
> `scaleReady` soit vrai, 8th Wall n'a pas encore convergé sur une estimation
> métrique, donc la valeur retournée n'a aucune raison de représenter quoi que
> ce soit de réel — même si elle y ressemble par coïncidence. La calibration ne
> casse rien, elle révèle pour la première fois l'estimation *réelle* du
> moteur (convergée, mais ici visiblement très biaisée). Le HUD étiquette
> maintenant ces lectures d'avant convergence « (pas encore calibré) » pour ne
> plus s'y laisser piéger. C'est très probablement ce qui a fait dérailler la
> tentative de calibration à deux points plus haut dans l'historique de ce
> fichier : les deux lectures mélangeaient un régime d'avant convergence avec
> un régime d'après — pas deux points sur une même droite.

### Le joueur apparaît trop grand (ou trop petit)

`reality.trackingstatus === 'NORMAL'` signifie que le suivi 6 degrés de liberté
est stable — **pas** que l'estimation métrique de l'échelle a fini de
converger. Sur certains appareils ou environnements (peu de texture au sol,
sol répétitif, mouvement de calibration trop bref), l'erreur peut être
importante alors même que le suivi fonctionne parfaitement. Des écarts d'un
facteur ~2 ont été observés sur le terrain.

**1. Un vrai déplacement est exigé avant de poser**, pas juste le statut.
`CONFIG.minCalibrationTravel` (0,6 m par défaut) est la distance totale que la
caméra doit avoir parcourue — une rotation sur place ne compte presque pas, il
faut une translation (avancer/reculer), qui est ce qui donne au SLAM la
parallaxe nécessaire. Le hint affiche la progression en direct. Ça améliore la
convergence, mais **ça ne la garantit pas**.

**2. Ajuster par comparaison VISUELLE, uniquement**, via :

```
https://<domaine>/?calibrate
```

Après une vraie calibration par déplacement, posez le repère 1,80 m à côté d'un
objet réel connu — porte (≈ 2,04-2,10 m), mètre ruban, une personne — et
ajustez avec les boutons ± jusqu'à ce que la taille affichée corresponde.
Reportez la valeur finale dans `CONFIG.slamScaleCorrection` (`src/config.js`)
— **mais seulement si vous la retrouvez de façon reproductible sur plusieurs
lieux.** Une valeur figée mesurée ailleurs se cumule silencieusement avec
l'erreur du moteur au lieu de la corriger ; c'est pourquoi le défaut est `1`.

La correction s'applique à trois endroits, via `src/lib/scale.js` :

- la **taille du personnage** ;
- le **diamètre du réticule** (0,45 m) — sinon il indiquerait une taille fausse
  au moment précis où on s'en sert comme repère ;
- **tous les seuils de distance** du placement (`minDropBelowCamera`,
  `maxPlacementDistance`, `floorBandTolerance`, `minCalibrationTravel`…). Sans
  cette conversion, un moteur à `k = 0,5` rendrait `minDropBelowCamera: 0.6`
  équivalent à 1,2 m réels et rejetterait des hits de sol valides — une cause
  supplémentaire de « aucune surface détectée ».

Elle est **globale** (tous les joueurs), contrairement au `calibration` par
joueur de `src/players.js`, qui corrige un défaut du *PNG* (sujet qui ne remplit
pas tout le détourage).

> **Pourquoi pas une formule automatique ?** Deux ont été essayées et
> abandonnées : `correction = affiché / réel` sur une lecture (mélange
> l'échelle avec le décalage du plan de sol), puis une variante à deux lectures
> à deux hauteurs censée annuler ce décalage par soustraction. La seconde s'est
> effondrée sur mesure réelle : en levant le téléphone de 0,19 m à 1,92 m
> (+1,73 m), la valeur affichée a **baissé** (0,50 → 0,20 m). Aucun modèle ne
> peut produire une lecture qui diminue quand la hauteur réelle augmente :
> l'estimation verticale du SLAM n'est tout simplement pas assez stable ici
> pour servir de signal de calcul, quelle que soit la formule. La comparaison
> visuelle reste, à ce jour, la seule méthode qui a produit un résultat correct
> sur le terrain dans ce projet.

---

## Bloqué au démarrage ?

L'écran de démarrage indique l'étape atteinte — **Moteur AR → Scène 3D → Caméra
→ Échelle** — et un journal détaillé s'ouvre avec `?debug` :

```
https://<ip-lan>:5173/?debug
```

Ce journal donne la compatibilité de l'appareil, les raisons d'incompatibilité en
clair, la présence du chunk SLAM et toute erreur JS capturée. C'est ce qu'il faut
lire en premier.

| Symptôme | Cause probable |
|---|---|
| **404 sur `xr.js`, `assets/index-*.js`, `xrextras.js`…** | Le dossier `dist` n'est pas servi à la racine du site. Utilisez `npm run preview`, ou déployez le **contenu** de `dist/` à la racine — pas le dossier `dist` lui-même dans un sous-répertoire, et jamais par double-clic sur `index.html`. Le build utilise désormais des chemins relatifs (`base: './'`), donc un sous-répertoire fonctionne aussi tant que la page et ses ressources restent au même niveau. |
| Page QR « Scan or visit… » | Vous êtes sur un ordinateur. L'AR exige un téléphone — scannez le QR, ou utilisez `?desktop` pour la mise en page seulement. |
| Bloqué longtemps sur **Moteur AR** | Le moteur pèse 6,5 Mo. Le serveur les sert désormais en gzip ; vérifiez que le téléphone et le PC sont sur le même réseau et que le pare-feu Windows autorise le port 5173. |
| Bloqué sur **Caméra** | Autorisation caméra refusée pour ce site. Le navigateur ne redemande pas après un refus : réautorisez dans les réglages du site. |
| « navigateur non supporté » | Vous avez ouvert le lien depuis un navigateur intégré (Instagram, Messenger, LinkedIn). Ouvrez-le dans Safari ou Chrome. |
| « capteurs de mouvement inaccessibles » | Page servie en `http://`, ou permission de mouvement refusée sur iOS. |
| Bloqué sur **Échelle** | Normal les premières secondes : avancez et reculez le téléphone jusqu'à la disparition de l'overlay. |

---

## Ce qui se passe au démarrage

L'ordre d'initialisation n'est pas cosmétique — deux courses ont été trouvées en
test automatisé et corrigées :

1. **A-Frame instancie les composants d'un `<a-scene>` dès l'analyse du HTML.**
   Notre code étant chargé en `type="module"` (donc différé), nos composants
   n'étaient pas encore enregistrés et étaient **silencieusement ignorés**.
2. **Le composant `coaching-overlay` lit la globale `XR8` dans son `init()`.**
   Comme `xr.js` est chargé en `async`, une scène initialisée trop tôt
   produisait un `ReferenceError: XR8 is not defined` bloquant.

D'où la séquence de `src/main.js` : enregistrer nos composants → attendre
`xrloaded` → **monter la scène depuis un `<template>`** → brancher le HUD.
C'est pourquoi `<a-scene>` vit dans un `<template>` et non directement dans le
corps du document.

Cette séquence a une conséquence qu'il faut gérer explicitement. En lisant le
binaire :

```js
yield Promise.all((chunks || []).map((c) => XR8.loadChunk(c)))
window.XR8 = engine
setTimeout(() => window.dispatchEvent(new CustomEvent('xrloaded')), 1)
```

`xrloaded` n'est émis **qu'après** le téléchargement de `xr.js` (1 Mo) *et* de
`xr-slam.js` (5,5 Mo). Pendant toute cette phase — la plus longue du démarrage —
aucun composant 8th Wall n'est actif : ni l'écran de chargement XRExtras, ni la
page « appareil non supporté ». Sans écran de démarrage propre, la page reste
figée et un échec réel est indiscernable d'un téléchargement lent.

D'où trois mesures :

- **`src/ui/boot-screen.js`** est dans le HTML dès le premier octet, affiche
  l'étape en cours, le temps écoulé, et capture les erreurs non interceptées ;
- le serveur de dev **compresse en gzip** (`vite.config.js`) — sans quoi les
  6,5 Mo partent bruts. Cela impose `proxy: {}`, qui force Vite en HTTP/1.1,
  car `compression` ne sait pas répondre en HTTP/2 ;
- sur un appareil incompatible, `xrweb` n'émet **plus aucun événement** : on
  détecte le cas via `XR8.XrDevice.isDeviceBrowserCompatible()` et on retire
  notre écran pour laisser apparaître la page QR de 8th Wall (z-index 815, elle
  était sinon masquée par nos overlays).

---

## Photo et partage

Le composant `xrweb` installe lui-même `XR8.CanvasScreenshot.pipelineModule()` et
câble `screenshotrequest` → `screenshotready` (JPEG en base64).

La capture porte sur le **canvas WebGL** : flux caméra + 3D. Le HUD est du HTML
posé au-dessus, il n'apparaît donc pas sur la photo — inutile de le masquer.
Seul le réticule, qui est dans la scène 3D, est retiré le temps du déclenchement.

**Le piège du partage natif :** `navigator.share()` exige une activation
transitoire, or la capture est asynchrone. Safari iOS invalide souvent
l'activation entre-temps. La stratégie est donc en deux temps : partage direct,
et si le navigateur refuse (`NotAllowedError`), affichage d'un panneau avec un
bouton « Partager » qui repart d'un geste neuf — plus un lien de téléchargement
pour les navigateurs sans Web Share (desktop, Firefox).

---

## Réglages utiles

| Fichier | Réglage |
|---|---|
| `src/config.js` | `orientationMode` : `'fixed'` (actuel), `'yaw'` (billboard), `'soft'` (fixe mais pivote au-delà de 55°) |
| `src/config.js` | `maxPlacementDistance`, `minDropBelowCamera`, `floorBandTolerance` — filtres de placement |
| `src/config.js` | `screenshot.maxDimension` / `jpgCompression` — qualité photo |
| `src/config.js` | `debugScale` — passez à `false` avant mise en production |
| `src/players.js` | catalogue, tailles réelles, `calibration`, `feetInset` |

**Sur `orientationMode`** — le mode actuel est `'fixed'` : le joueur garde
l'orientation qu'il avait au moment du placement. C'est le comportement demandé,
mais un découpage plat vu de profil devient invisible. Si vos utilisateurs
tournent beaucoup autour du personnage, `'soft'` est un bon compromis : il reste
fixe tant que l'angle reste lisible, et ne pivote qu'au-delà.

---

## Architecture

```
index.html                      scripts vendeurs + <template> de scène + HUD
vite.config.js                  copie des dist 8th Wall, HTTPS de dev
src/
  main.js                       séquence de démarrage
  config.js                     réglages globaux
  players.js                    catalogue des personnages
  lib/
    texture.js                  recadrage alpha, texture d'ombre
    hit-test.js                 hitTest, filtrage, estimateur de sol
    scale.js                    mètres réels <-> unités de scène, calibration 2 points
  components/
    real-scale-figure.js        plan dimensionné en mètres réels
    contact-shadow.js           ombre de contact au sol
    ground-reticle.js           réticule de visée
    ar-director.js              états, taps, placement, orientation
  ui/
    photo.js                    capture + partage natif
    hud.js                      interface HTML
public/players/                 PNG détourés
tests/                          banc de test hors AR (Playwright)
```

---

## Licence du moteur

Le binaire 8th Wall est distribué sous **XR Engine License Agreement**
(Niantic Spatial, Inc.) — ce n'est **pas** de l'open source.

- L'en-tête de copyright en tête de `external/xr/xr.js` doit être **conservé**
  (ne le supprimez pas au minify). L'attribution est aussi rappelée en
  commentaire dans `index.html` et en pied de HUD.
- Usage commercial autorisé **sauf** si votre produit est payant *et* que sa
  valeur dérive entièrement ou substantiellement du moteur.
- Licence révocable, pas de rétro-ingénierie, pas de sous-licence.
- VPS, Area Targets, Lightship Maps et le hand tracking ne sont **pas** inclus
  dans ce binaire.

Texte complet : <https://github.com/8thwall/engine/blob/main/LICENSE>

Aucune clé d'application n'est nécessaire : le binaire ne fait aucun appel
d'autorisation. Gardez en revanche le fichier nommé exactement `xr.js` — le
moteur retrouve sa propre balise script via la regex `/(xrweb|xr\.js)(\?.*)?$/`.

---

## Limites connues

- **Pas d'occlusion.** Le joueur s'affiche par-dessus les objets réels ; si
  quelqu'un passe devant lui, l'illusion se rompt. L'occlusion par profondeur
  n'est pas exposée par ce binaire.
- **Découpage plat.** En mode `'fixed'`, vu de côté, le personnage disparaît.
- **Sols peu texturés ou répétitifs** (moquette unie, béton lisse, carrelage) :
  peu de points de feature, donc peu ou pas de hits exactement là où l'on vise.
  `findGroundHit` élargit déjà la recherche à un petit voisinage (voir plus
  haut) pour absorber ça, mais un sol vraiment uniforme reste une limite
  physique du SLAM monoculaire, pas un bug applicatif. Si « Aucune surface
  détectée ici » persiste malgré plusieurs essais : visez un point contrasté
  (un joint de carrelage, le bord d'un tapis, une tache, un pied de meuble)
  plutôt que le centre d'une dalle unie, et évitez le carrelage brillant sous
  un éclairage direct (le reflet spéculaire bouge avec la caméra et empêche
  tout matching).
- **Support de l'absolute scale par appareil** : non documenté par 8th Wall, et
  `XR8.XrDevice` n'expose aucun indicateur de capacité. Le verrou sur
  `xrtrackingstatus` est le seul garde-fou fiable.
